package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.MathQuestionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MathQuestionDao {
    @Query("SELECT * FROM math_questions ORDER BY id DESC")
    fun getAllQuestions(): Flow<List<MathQuestionEntity>>

    @Query("SELECT * FROM math_questions WHERE isCustom = 1 ORDER BY id DESC")
    fun getCustomQuestions(): Flow<List<MathQuestionEntity>>

    @Query("SELECT * FROM math_questions")
    suspend fun getAllQuestionsList(): List<MathQuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: MathQuestionEntity): Long

    @Delete
    suspend fun deleteQuestion(question: MathQuestionEntity)

    @Query("DELETE FROM math_questions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM math_questions")
    suspend fun getCount(): Int
}
