package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.ParentSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("kid_timer_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<ParentSettings> = _settings.asStateFlow()

    private fun loadSettings(): ParentSettings {
        return ParentSettings(
            parentPin = prefs.getString(KEY_PIN, "1234") ?: "1234",
            pinRequiredToStop = prefs.getBoolean(KEY_PIN_REQUIRED, true),
            useDeviceAdminLock = prefs.getBoolean(KEY_ADMIN_LOCK, true),
            useOverlayLockScreen = prefs.getBoolean(KEY_OVERLAY_LOCK, true),
            warningSoundBeforeOneMinute = prefs.getBoolean(KEY_SOUND_WARN, false),
            vibrateOnLock = prefs.getBoolean(KEY_VIBRATE, true),
            mathChallengeEnabled = prefs.getBoolean(KEY_MATH_ENABLED, true),
            mathChallengeIntervalMinutes = prefs.getInt(KEY_MATH_INTERVAL, 5),
            mathChallengeDurationSeconds = prefs.getInt(KEY_MATH_DURATION, 20),
            appLockEnabled = prefs.getBoolean(KEY_APP_LOCK, true)
        )
    }

    /** Re-reads the stored settings, so long-running components see the latest parent choices. */
    fun current(): ParentSettings {
        val fresh = loadSettings()
        _settings.value = fresh
        return fresh
    }

    fun savePin(newPin: String) {
        prefs.edit().putString(KEY_PIN, newPin).apply()
        _settings.value = _settings.value.copy(parentPin = newPin)
    }

    fun updateSettings(
        pinRequiredToStop: Boolean,
        useDeviceAdminLock: Boolean,
        useOverlayLockScreen: Boolean,
        warningSoundBeforeOneMinute: Boolean,
        vibrateOnLock: Boolean,
        mathChallengeEnabled: Boolean = _settings.value.mathChallengeEnabled,
        mathChallengeIntervalMinutes: Int = _settings.value.mathChallengeIntervalMinutes,
        mathChallengeDurationSeconds: Int = _settings.value.mathChallengeDurationSeconds,
        appLockEnabled: Boolean = _settings.value.appLockEnabled
    ) {
        prefs.edit()
            .putBoolean(KEY_PIN_REQUIRED, pinRequiredToStop)
            .putBoolean(KEY_ADMIN_LOCK, useDeviceAdminLock)
            .putBoolean(KEY_OVERLAY_LOCK, useOverlayLockScreen)
            .putBoolean(KEY_SOUND_WARN, warningSoundBeforeOneMinute)
            .putBoolean(KEY_VIBRATE, vibrateOnLock)
            .putBoolean(KEY_MATH_ENABLED, mathChallengeEnabled)
            .putInt(KEY_MATH_INTERVAL, mathChallengeIntervalMinutes)
            .putInt(KEY_MATH_DURATION, mathChallengeDurationSeconds)
            .putBoolean(KEY_APP_LOCK, appLockEnabled)
            .apply()

        _settings.value = _settings.value.copy(
            pinRequiredToStop = pinRequiredToStop,
            useDeviceAdminLock = useDeviceAdminLock,
            useOverlayLockScreen = useOverlayLockScreen,
            warningSoundBeforeOneMinute = warningSoundBeforeOneMinute,
            vibrateOnLock = vibrateOnLock,
            mathChallengeEnabled = mathChallengeEnabled,
            mathChallengeIntervalMinutes = mathChallengeIntervalMinutes,
            mathChallengeDurationSeconds = mathChallengeDurationSeconds,
            appLockEnabled = appLockEnabled
        )
    }

    fun updateMathChallengeSettings(
        enabled: Boolean,
        intervalMinutes: Int,
        durationSeconds: Int
    ) {
        prefs.edit()
            .putBoolean(KEY_MATH_ENABLED, enabled)
            .putInt(KEY_MATH_INTERVAL, intervalMinutes)
            .putInt(KEY_MATH_DURATION, durationSeconds)
            .apply()

        _settings.value = _settings.value.copy(
            mathChallengeEnabled = enabled,
            mathChallengeIntervalMinutes = intervalMinutes,
            mathChallengeDurationSeconds = durationSeconds
        )
    }

    companion object {
        private const val KEY_PIN = "key_parent_pin"
        private const val KEY_PIN_REQUIRED = "key_pin_required"
        private const val KEY_ADMIN_LOCK = "key_admin_lock"
        private const val KEY_OVERLAY_LOCK = "key_overlay_lock"
        private const val KEY_SOUND_WARN = "key_sound_warn"
        private const val KEY_VIBRATE = "key_vibrate"
        private const val KEY_MATH_ENABLED = "key_math_enabled"
        private const val KEY_MATH_INTERVAL = "key_math_interval"
        private const val KEY_MATH_DURATION = "key_math_duration"
        private const val KEY_APP_LOCK = "key_app_lock"
    }
}
