package com.example.ui.tabs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.MathQuestionEntity
import com.example.model.ParentSettings
import com.example.ui.components.PermissionCard
import com.example.ui.theme.Amber400
import com.example.ui.theme.Cyan400
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Indigo500
import com.example.ui.theme.Red500
import com.example.ui.theme.Slate800

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: ParentSettings,
    mathQuestions: List<MathQuestionEntity>,
    isDeviceAdminActive: Boolean,
    hasUsageStatsPermission: Boolean,
    hasNotificationPermission: Boolean,
    hasOverlayPermission: Boolean,
    onRequestOverlay: () -> Unit,
    onRequestDeviceAdmin: () -> Unit,
    onRequestUsageStats: () -> Unit,
    onRequestNotification: () -> Unit,
    onSavePin: (String) -> Unit,
    onUpdateSettings: (
        pinRequiredToStop: Boolean,
        useDeviceAdminLock: Boolean,
        useOverlayLockScreen: Boolean,
        warningSoundBeforeOneMinute: Boolean,
        vibrateOnLock: Boolean,
        mathChallengeEnabled: Boolean,
        mathChallengeIntervalMinutes: Int,
        mathChallengeDurationSeconds: Int,
        appLockEnabled: Boolean
    ) -> Unit,
    onAddMathQuestion: (question: String, answer: String, wrong1: String, wrong2: String, difficulty: Int) -> Unit,
    onDeleteMathQuestion: (id: Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAddQuestionDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(
            text = "إعدادات الأمان والقفل ⚙️",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "تخصيص طرق القفل التلقائي وتمارين الرياضيات لحماية وقت الطفل",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Permissions Health Card
        PermissionCard(
            isDeviceAdminActive = isDeviceAdminActive,
            hasUsageStatsPermission = hasUsageStatsPermission,
            hasNotificationPermission = hasNotificationPermission,
            hasOverlayPermission = hasOverlayPermission,
            onRequestDeviceAdmin = onRequestDeviceAdmin,
            onRequestUsageStats = onRequestUsageStats,
            onRequestNotification = onRequestNotification,
            onRequestOverlay = onRequestOverlay
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Math Challenge Settings Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
            modifier = Modifier.fillMaxWidth().testTag("math_challenge_settings_card")
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Slate800)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Calculate,
                                contentDescription = null,
                                tint = Cyan400,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "تمارين الرياضيات الدورية",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "ظهور تمرين حسابي دوري للطفل مع 3 خيارات ومؤقت سريع",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Switch(
                        checked = settings.mathChallengeEnabled,
                        onCheckedChange = {
                            onUpdateSettings(
                                settings.pinRequiredToStop,
                                settings.useDeviceAdminLock,
                                settings.useOverlayLockScreen,
                                false,
                                settings.vibrateOnLock,
                                it,
                                settings.mathChallengeIntervalMinutes,
                                settings.mathChallengeDurationSeconds,
                                settings.appLockEnabled
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = Cyan400
                        ),
                        modifier = Modifier.testTag("switch_math_challenge")
                    )
                }

                AnimatedVisibility(visible = settings.mathChallengeEnabled) {
                    Column(modifier = Modifier.padding(top = 16.dp)) {
                        Text(
                            text = "تكرار ظهور التمارين أثناء استخدام الهاتف:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val intervals = listOf(1, 2, 3, 5, 10, 15)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            for (interval in intervals) {
                                val isSelected = settings.mathChallengeIntervalMinutes == interval
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) Cyan400 else Slate800)
                                        .clickable {
                                            onUpdateSettings(
                                                settings.pinRequiredToStop,
                                                settings.useDeviceAdminLock,
                                                settings.useOverlayLockScreen,
                                                false,
                                                settings.vibrateOnLock,
                                                settings.mathChallengeEnabled,
                                                interval,
                                                settings.mathChallengeDurationSeconds,
                                                settings.appLockEnabled
                                            )
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .testTag("math_interval_${interval}m")
                                ) {
                                    Text(
                                        text = if (interval == 1) "كل دقيقة واحدة" else "كل $interval د",
                                        color = if (isSelected) DarkBackground else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "مدة الإجابة على التمرين:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val durations = listOf(10, 15, 20, 30, 45)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            for (seconds in durations) {
                                val isSelected = settings.mathChallengeDurationSeconds == seconds
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) Cyan400 else Slate800)
                                        .clickable {
                                            onUpdateSettings(
                                                settings.pinRequiredToStop,
                                                settings.useDeviceAdminLock,
                                                settings.useOverlayLockScreen,
                                                false,
                                                settings.vibrateOnLock,
                                                settings.mathChallengeEnabled,
                                                settings.mathChallengeIntervalMinutes,
                                                seconds,
                                                settings.appLockEnabled
                                            )
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .testTag("math_duration_${seconds}s")
                                ) {
                                    Text(
                                        text = "$seconds ثانية",
                                        color = if (isSelected) DarkBackground else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        val context = androidx.compose.ui.platform.LocalContext.current
                        Button(
                            onClick = {
                                val testIntent = android.content.Intent(
                                    context,
                                    com.example.ui.challenge.MathChallengeActivity::class.java
                                ).apply {
                                    putExtra(com.example.ui.challenge.MathChallengeActivity.EXTRA_DIFFICULTY, 1)
                                    putExtra(
                                        com.example.ui.challenge.MathChallengeActivity.EXTRA_TIME_LIMIT_SECONDS,
                                        settings.mathChallengeDurationSeconds
                                    )
                                    flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(testIntent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Slate800, contentColor = Cyan400),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("btn_test_math_challenge_now")
                        ) {
                            Icon(imageVector = Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "معاينة وتجربة التمرين الرياضي الآن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Custom Questions Bank Section Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "بنك التمارين الرياضية (${mathQuestions.size} تمرين)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "يمكنك إضافة مسائل مخصصة لطفلك أو حذفها",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = { showAddQuestionDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Slate800, contentColor = Cyan400),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("btn_add_math_question")
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "إضافة مسألة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Questions List
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (q in mathQuestions) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Slate800.copy(alpha = 0.6f))
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .testTag("question_item_${q.id}")
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = q.questionText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "الإجابة: ${q.correctAnswer}  |  الخيارات: ${q.wrongOption1}، ${q.wrongOption2}",
                                            fontSize = 11.sp,
                                            color = Cyan400
                                        )
                                    }

                                    IconButton(
                                        onClick = { onDeleteMathQuestion(q.id) },
                                        modifier = Modifier.size(32.dp).testTag("btn_delete_question_${q.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "حذف",
                                            tint = Red500,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Parent PIN Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Slate800)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Password,
                                contentDescription = null,
                                tint = Cyan400,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "رمز أمان الوالدين (PIN)",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "الرمز محفوظ ومحمي (4 أرقام)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = { showChangePinDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Slate800, contentColor = Cyan400),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_change_pin")
                    ) {
                        Text(text = "تغيير", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle: Require PIN to stop timer
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "طلب الرمز لإلغاء أو إيقاف المؤقت",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "يمنع الطفل من الضغط على زر الإيقاف لتعطيل الوقت",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = settings.pinRequiredToStop,
                        onCheckedChange = {
                            onUpdateSettings(
                                it,
                                settings.useDeviceAdminLock,
                                settings.useOverlayLockScreen,
                                false,
                                settings.vibrateOnLock,
                                settings.mathChallengeEnabled,
                                settings.mathChallengeIntervalMinutes,
                                settings.mathChallengeDurationSeconds,
                                settings.appLockEnabled
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = Cyan400
                        ),
                        modifier = Modifier.testTag("switch_pin_required")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Lock & Alert Behavior Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "سلوك القفل والتنبيهات 🔒",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle: Hardware System Lock (lockNow)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "قفل نظام الهاتف وإطفاء الشاشة (مسؤول الجهاز)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "يجبر الهاتف على طلب البصمة أو الرمز الفعلي للهاتف فور انتهاء المؤقت",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = settings.useDeviceAdminLock,
                        onCheckedChange = {
                            onUpdateSettings(
                                settings.pinRequiredToStop,
                                it,
                                settings.useOverlayLockScreen,
                                false,
                                settings.vibrateOnLock,
                                settings.mathChallengeEnabled,
                                settings.mathChallengeIntervalMinutes,
                                settings.mathChallengeDurationSeconds,
                                settings.appLockEnabled
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = Cyan400
                        ),
                        modifier = Modifier.testTag("switch_admin_lock")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle: Overlay lock screen
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "شاشة قفل الطفل المباشرة",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "عرض شاشة ملء الهاتف تنبه بانتهاء الوقت وتطلب رمز الوالدين",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = settings.useOverlayLockScreen,
                        onCheckedChange = {
                            onUpdateSettings(
                                settings.pinRequiredToStop,
                                settings.useDeviceAdminLock,
                                it,
                                false,
                                settings.vibrateOnLock,
                                settings.mathChallengeEnabled,
                                settings.mathChallengeIntervalMinutes,
                                settings.mathChallengeDurationSeconds,
                                settings.appLockEnabled
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = Cyan400
                        ),
                        modifier = Modifier.testTag("switch_overlay_lock")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle: App Lock during active timer
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "قفل التطبيق برمز الوالدين أثناء تشغيل المؤقت 🔒",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "يمنع الطفل تماماً من الدخول للتطبيق أو تعديل الوقت أو إيقاف العداد",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = settings.appLockEnabled,
                        onCheckedChange = {
                            onUpdateSettings(
                                settings.pinRequiredToStop,
                                settings.useDeviceAdminLock,
                                settings.useOverlayLockScreen,
                                false, // audio alert removed
                                settings.vibrateOnLock,
                                settings.mathChallengeEnabled,
                                settings.mathChallengeIntervalMinutes,
                                settings.mathChallengeDurationSeconds,
                                it
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = Cyan400
                        ),
                        modifier = Modifier.testTag("switch_app_lock")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle: Vibrate
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "اهتزاز الهاتف عند انتهاء الوقت",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "تأكيد إيقاف الهاتف باهتزاز قوي ملحوظ",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = settings.vibrateOnLock,
                        onCheckedChange = {
                            onUpdateSettings(
                                settings.pinRequiredToStop,
                                settings.useDeviceAdminLock,
                                settings.useOverlayLockScreen,
                                false,
                                it,
                                settings.mathChallengeEnabled,
                                settings.mathChallengeIntervalMinutes,
                                settings.mathChallengeDurationSeconds,
                                settings.appLockEnabled
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = Cyan400
                        ),
                        modifier = Modifier.testTag("switch_vibrate")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // How it works info card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Slate800),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Cyan400,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "كيف يعمل برنامج KidTimer؟",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "1. حدد المؤقت (مثلاً 15 دقيقة أو أكثر بزيادات 5 دقائق) واضغط بدء المؤقت.\n" +
                            "2. أثناء تشغيل المؤقت، يظهر للطفل تمرين رياضي سريع حسب الفاصل الزمني الذي تحدده، وبمجرد إجابته يعود مباشرة لتطبيقه.\n" +
                            "3. فور انتهاء الوقت، يقفل التطبيق الهاتف تلقائياً ويطالب بالرمز أو البصمة لإعادة الفتح حتى لو كان الطفل يشاهد فيديو أو يلعب لعبة.\n" +
                            "4. يمكنك العودة لتبويب الإحصائيات لمعرفة ما هي التطبيقات التي قام الطفل بالدخول عليها بدقة.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Add Question Dialog
    if (showAddQuestionDialog) {
        AddMathQuestionDialog(
            onAdd = { question, answer, wrong1, wrong2, diff ->
                onAddMathQuestion(question, answer, wrong1, wrong2, diff)
                showAddQuestionDialog = false
            },
            onDismiss = { showAddQuestionDialog = false }
        )
    }

    // Change PIN Dialog
    if (showChangePinDialog) {
        ChangePinDialog(
            currentPin = settings.parentPin,
            onPinChanged = { newPin ->
                onSavePin(newPin)
                showChangePinDialog = false
            },
            onDismiss = { showChangePinDialog = false }
        )
    }
}

@Composable
private fun AddMathQuestionDialog(
    onAdd: (question: String, answer: String, wrong1: String, wrong2: String, difficulty: Int) -> Unit,
    onDismiss: () -> Unit
) {
    var questionText by remember { mutableStateOf("") }
    var answerText by remember { mutableStateOf("") }
    var wrongOption1 by remember { mutableStateOf("") }
    var wrongOption2 by remember { mutableStateOf("") }
    var difficultyLevel by remember { mutableIntStateOf(1) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
            modifier = Modifier.fillMaxWidth().testTag("add_question_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "إضافة تمرين رياضي جديد 🧮",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = questionText,
                    onValueChange = { questionText = it },
                    label = { Text("المسألة (مثال: 7 + 8 = ؟ أو 6 × 4)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan400,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_question_text")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = answerText,
                    onValueChange = { answerText = it },
                    label = { Text("الإجابة الصحيحة (مثال: 15)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan400,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_correct_answer")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = wrongOption1,
                        onValueChange = { wrongOption1 = it },
                        label = { Text("خيار خاطئ 1") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan400,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.weight(1f).testTag("input_wrong_1")
                    )

                    OutlinedTextField(
                        value = wrongOption2,
                        onValueChange = { wrongOption2 = it },
                        label = { Text("خيار خاطئ 2") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan400,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.weight(1f).testTag("input_wrong_2")
                    )
                }

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg ?: "", color = Red500, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = onDismiss) {
                        Text(text = "إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            when {
                                questionText.isBlank() -> errorMsg = "يرجى كتابة نص المسألة"
                                answerText.isBlank() -> errorMsg = "يرجى تحديد الإجابة الصحيحة"
                                wrongOption1.isBlank() || wrongOption2.isBlank() -> errorMsg = "يرجى إدخال خيارين خاطئين"
                                wrongOption1.trim() == answerText.trim() || wrongOption2.trim() == answerText.trim() ->
                                    errorMsg = "الخيارات الخاطئة يجب أن تختلف عن الإجابة الصحيحة"
                                wrongOption1.trim() == wrongOption2.trim() ->
                                    errorMsg = "يجب أن يكون الخياران الخاطئان مختلفين"
                                else -> onAdd(questionText.trim(), answerText.trim(), wrongOption1.trim(), wrongOption2.trim(), difficultyLevel)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan400, contentColor = DarkBackground),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_confirm_add_question")
                    ) {
                        Text(text = "إضافة التمرين", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChangePinDialog(
    currentPin: String,
    onPinChanged: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var oldPinInput by remember { mutableStateOf("") }
    var newPinInput by remember { mutableStateOf("") }
    var confirmPinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
            modifier = Modifier.fillMaxWidth().testTag("change_pin_dialog")
        ) {
            Column(modifier = Modifier.padding(22.dp)) {
                Text(
                    text = "تغيير رمز المرور (PIN)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = oldPinInput,
                    onValueChange = { if (it.length <= 4) oldPinInput = it },
                    label = { Text("الرمز الحالي (4 أرقام)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan400,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_old_pin")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = newPinInput,
                    onValueChange = { if (it.length <= 4) newPinInput = it },
                    label = { Text("الرمز الجديد (4 أرقام)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan400,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_new_pin")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = confirmPinInput,
                    onValueChange = { if (it.length <= 4) confirmPinInput = it },
                    label = { Text("تأكيد الرمز الجديد") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan400,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_confirm_pin")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = Red500,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(text = "إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            when {
                                oldPinInput != currentPin -> errorMessage = "الرمز الحالي غير صحيح!"
                                newPinInput.length != 4 -> errorMessage = "يجب أن يتكون الرمز الجديد من 4 أرقام"
                                newPinInput != confirmPinInput -> errorMessage = "الرمز الجديد وتأكيده غير متطابقين"
                                else -> onPinChanged(newPinInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan400, contentColor = DarkBackground),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_save_new_pin")
                    ) {
                        Text(text = "حفظ الرمز", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
