package com.example.ui.challenge

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppDatabase
import com.example.model.MathChallenge
import com.example.service.KidTimerService
import com.example.ui.theme.Amber400
import com.example.ui.theme.Cyan400
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Emerald500
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Red500
import com.example.ui.theme.Slate800
import com.example.util.MathChallengeGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * تمرين واحد لكل فترة. إجابة صحيحة = +1 دقيقة، خاطئة أو بلا إجابة = -1 دقيقة.
 */
class MathChallengeActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            (getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)
                ?.requestDismissKeyguard(this, null)
        }

        // الطفل لا يستطيع إغلاق التمرين بزر الرجوع
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })

        val difficulty = intent.getIntExtra(EXTRA_DIFFICULTY, 1)
        val timeLimit = intent.getIntExtra(EXTRA_TIME_LIMIT_SECONDS, DEFAULT_TIME_LIMIT_SECONDS)
            .coerceIn(MIN_TIME_LIMIT_SECONDS, MAX_TIME_LIMIT_SECONDS)

        setContent {
            MyApplicationTheme {
                MathChallengeScreen(
                    initialDifficulty = difficulty,
                    timeLimitSeconds = timeLimit,
                    onResult = { correct ->
                        KidTimerService.adjustOneMinute(this, if (correct) 1 else -1)
                    },
                    onClose = { finish() }
                )
            }
        }
    }

    companion object {
        const val EXTRA_DIFFICULTY = "extra_difficulty"
        const val EXTRA_TIME_LIMIT_SECONDS = "extra_time_limit_seconds"
        const val DEFAULT_TIME_LIMIT_SECONDS = 20
        const val MIN_TIME_LIMIT_SECONDS = 10
        const val MAX_TIME_LIMIT_SECONDS = 60
    }
}

@Composable
fun MathChallengeScreen(
    initialDifficulty: Int,
    timeLimitSeconds: Int,
    onResult: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var challenge by remember { mutableStateOf<MathChallenge?>(null) }
    var selectedOption by remember { mutableStateOf<String?>(null) }
    var answered by remember { mutableStateOf(false) }
    var resultCorrect by remember { mutableStateOf<Boolean?>(null) }
    var timeLeft by remember { mutableIntStateOf(timeLimitSeconds) }

    // تحميل سؤال واحد لهذه الفترة
    LaunchedEffect(Unit) {
        val customQuestions = withContext(Dispatchers.IO) {
            try {
                AppDatabase.getInstance(context).mathQuestionDao().getAllQuestionsList()
            } catch (_: Exception) {
                emptyList()
            }
        }
        challenge = MathChallengeGenerator.getNextChallenge(customQuestions, initialDifficulty)
    }

    // العد التنازلي: انتهاء الوقت يُحسب إجابة خاطئة
    LaunchedEffect(Unit) {
        while (timeLeft > 0 && !answered) {
            delay(1000L)
            if (!answered) timeLeft -= 1
        }
        if (!answered) {
            answered = true
            resultCorrect = false
            onResult(false)
            delay(1500L)
            onClose()
        }
    }

    fun answer(option: String, ch: MathChallenge) {
        if (answered) return
        answered = true
        selectedOption = option
        val correct = option.trim() == ch.correctAnswer.trim()
        resultCorrect = correct
        onResult(correct)
        scope.launch {
            delay(1500L)
            onClose()
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = DarkBackground) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(24.dp)
        ) {
            Spacer(modifier = Modifier.height(40.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Slate800)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Calculate, contentDescription = null, tint = Cyan400, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "تحدي التفكير الرياضي 🧮", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "إجابة صحيحة = +1 دقيقة  •  إجابة خاطئة أو تأخير = -1 دقيقة",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Icon(
                    Icons.Default.Timer,
                    contentDescription = null,
                    tint = if (timeLeft <= 5) Red500 else Amber400,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                LinearProgressIndicator(
                    progress = { timeLeft.toFloat() / timeLimitSeconds.toFloat() },
                    color = if (timeLeft <= 5) Red500 else Cyan400,
                    trackColor = Slate800,
                    modifier = Modifier.weight(1f).height(8.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = "$timeLeft ث", fontWeight = FontWeight.Bold, color = if (timeLeft <= 5) Red500 else Color.White, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(28.dp))

            challenge?.let { ch ->
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkCardBorder)),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 16.dp)
                    ) {
                        Text(text = "المسألة الرياضية", fontSize = 12.sp, color = Cyan400, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = ch.question,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                ) {
                    for ((index, option) in ch.options.withIndex()) {
                        val isCorrectOption = option.trim() == ch.correctAnswer.trim()
                        val isSelected = selectedOption == option
                        val bg = when {
                            answered && isCorrectOption -> Emerald500
                            isSelected && resultCorrect == false -> Red500
                            else -> DarkSurface
                        }
                        Card(
                            onClick = { answer(option, ch) },
                            enabled = !answered,
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = bg),
                            modifier = Modifier.fillMaxWidth().height(64.dp).testTag("option_button_$index")
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                Text(text = option, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                when {
                    resultCorrect == true -> Text(
                        text = "✓ إجابة صحيحة! +1 دقيقة",
                        color = Emerald500, fontWeight = FontWeight.Bold, fontSize = 15.sp
                    )
                    resultCorrect == false && selectedOption != null -> Text(
                        text = "✕ إجابة خاطئة! -1 دقيقة",
                        color = Red500, fontWeight = FontWeight.Bold, fontSize = 15.sp
                    )
                    resultCorrect == false -> Text(
                        text = "⏰ انتهى الوقت! -1 دقيقة",
                        color = Red500, fontWeight = FontWeight.Bold, fontSize = 15.sp
                    )
                    else -> Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}