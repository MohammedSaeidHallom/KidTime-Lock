package com.example.ui.lock

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.example.data.PreferencesManager

object KidLockOverlayManager {

    private var windowManager: WindowManager? = null
    private var lockView: View? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    var isShowing: Boolean = false
        private set

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    fun show(context: Context, onUnlocked: (() -> Unit)? = null): Boolean {
        if (!Settings.canDrawOverlays(context)) {
            return false
        }

        mainHandler.post {
            try {
                if (isShowing && lockView != null) {
                    return@post
                }

                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                windowManager = wm

                val windowLayoutParams = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    } else {
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                    },
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                            WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.CENTER
                }

                val density = context.resources.displayMetrics.density
                fun dp(value: Float): Int = (value * density + 0.5f).toInt()

                val rootLayout = FrameLayout(context).apply {
                    setBackgroundColor(Color.parseColor("#FA0F172A")) // Opaque slate
                    isClickable = true
                    isFocusable = true
                }

                val cardLayout = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    val cardBg = GradientDrawable().apply {
                        setColor(Color.parseColor("#1E293B"))
                        cornerRadius = dp(24f).toFloat()
                        setStroke(dp(1.5f), Color.parseColor("#EF4444")) // Red warning outline
                    }
                    background = cardBg
                    setPadding(dp(20f), dp(24f), dp(20f), dp(24f))
                }

                val cardParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.CENTER
                    marginStart = dp(20f)
                    marginEnd = dp(20f)
                }
                rootLayout.addView(cardLayout, cardParams)

                // Lock Icon and Title
                val lockIconText = TextView(context).apply {
                    text = "🔒"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 46f)
                    gravity = Gravity.CENTER
                }
                cardLayout.addView(lockIconText)

                val lockTitle = TextView(context).apply {
                    text = "انتهى وقت الهاتف!"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(0, dp(8f), 0, dp(4f))
                }
                cardLayout.addView(lockTitle)

                val lockSubtitle = TextView(context).apply {
                    text = "انتهى وقت الشاشة المحدد لطفلك.\nيرجى إعطاء الهاتف للوالدين لإلغاء القفل."
                    setTextColor(Color.parseColor("#94A3B8"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    gravity = Gravity.CENTER
                    setPadding(dp(12f), dp(4f), dp(12f), dp(16f))
                }
                cardLayout.addView(lockSubtitle)

                // PIN dots indicators
                val enteredPin = StringBuilder()
                val pinIndicator = TextView(context).apply {
                    text = "○  ○  ○  ○"
                    setTextColor(Color.parseColor("#38BDF8"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(0, dp(8f), 0, dp(12f))
                }
                cardLayout.addView(pinIndicator)

                val errorText = TextView(context).apply {
                    text = ""
                    setTextColor(Color.parseColor("#EF4444"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(0, 0, 0, dp(12f))
                }
                cardLayout.addView(errorText)

                val prefs = PreferencesManager(context)
                val correctPin = prefs.current().parentPin

                fun updatePinView() {
                    val count = enteredPin.length
                    val dots = StringBuilder()
                    for (i in 0 until 4) {
                        if (i < count) dots.append("●  ") else dots.append("○  ")
                    }
                    pinIndicator.text = dots.toString().trim()
                }

                fun checkPin() {
                    if (enteredPin.length == 4) {
                        if (enteredPin.toString() == correctPin) {
                            errorText.setTextColor(Color.parseColor("#10B981"))
                            errorText.text = "تم فتح القفل بنجاح ✓"
                            mainHandler.postDelayed({
                                dismiss()
                                onUnlocked?.invoke()
                            }, 400L)
                        } else {
                            errorText.setTextColor(Color.parseColor("#EF4444"))
                            errorText.text = "رمز PIN غير صحيح! حاول مرة أخرى"
                            enteredPin.clear()
                            updatePinView()
                            try {
                                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
                                } else {
                                    @Suppress("DEPRECATION")
                                    context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                                }
                                vibrator?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                            } catch (_: Exception) {}
                        }
                    }
                }

                // Numeric Keypad Grid
                val grid = GridLayout(context).apply {
                    columnCount = 3
                    alignmentMode = GridLayout.ALIGN_BOUNDS
                }
                val gridParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                }

                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "مسح", "0", "⌫")
                for (key in keys) {
                    val btn = Button(context).apply {
                        text = key
                        setTextColor(Color.WHITE)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                        typeface = Typeface.DEFAULT_BOLD
                        val btnBg = GradientDrawable().apply {
                            setColor(Color.parseColor("#334155"))
                            cornerRadius = dp(12f).toFloat()
                        }
                        background = btnBg

                        setOnClickListener {
                            when (key) {
                                "مسح" -> {
                                    enteredPin.clear()
                                    errorText.text = ""
                                    updatePinView()
                                }
                                "⌫" -> {
                                    if (enteredPin.isNotEmpty()) {
                                        enteredPin.deleteCharAt(enteredPin.length - 1)
                                        errorText.text = ""
                                        updatePinView()
                                    }
                                }
                                else -> {
                                    if (enteredPin.length < 4) {
                                        enteredPin.append(key)
                                        errorText.text = ""
                                        updatePinView()
                                        if (enteredPin.length == 4) {
                                            checkPin()
                                        }
                                    }
                                }
                            }
                        }
                    }
                    val btnParams = GridLayout.LayoutParams().apply {
                        width = dp(76f)
                        height = dp(52f)
                        setMargins(dp(6f), dp(4f), dp(6f), dp(4f))
                    }
                    grid.addView(btn, btnParams)
                }
                cardLayout.addView(grid, gridParams)

                wm.addView(rootLayout, windowLayoutParams)
                lockView = rootLayout
                isShowing = true
            } catch (e: Exception) {
                e.printStackTrace()
                isShowing = false
            }
        }
        return true
    }

    fun dismiss() {
        mainHandler.post {
            try {
                if (isShowing && lockView != null && windowManager != null) {
                    windowManager?.removeView(lockView)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                lockView = null
                isShowing = false
            }
        }
    }
}
