package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)

val Cyan500 = Color(0xFF06B6D4)
val Cyan400 = Color(0xFF22D3EE)
val Cyan300 = Color(0xFF67E8F9)
val Indigo600 = Color(0xFF4F46E5)
val Indigo500 = Color(0xFF6366F1)
val Amber500 = Color(0xFFF59E0B)
val Amber400 = Color(0xFFFBBF24)
val Emerald500 = Color(0xFF10B981)
val Rose500 = Color(0xFFF43F5E)
val Red500 = Color(0xFFEF4444)

val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF131A2B)
val DarkSurfaceVariant = Color(0xFF1E273D)
val DarkCardBorder = Color(0xFF2A3654)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
