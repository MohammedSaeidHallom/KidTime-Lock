package com.example.util

import com.example.model.MathChallenge
import com.example.model.MathQuestionEntity
import kotlin.random.Random

object MathChallengeGenerator {

    /**
     * Generates a math challenge. If parent custom questions exist, randomly blends them.
     * Otherwise generates a dynamic procedural math exercise with difficulty scaled by difficultyLevel (1..5).
     */
    fun getNextChallenge(
        customQuestions: List<MathQuestionEntity>,
        difficultyLevel: Int = 1
    ): MathChallenge {
        // 40% chance to select a parent custom question if available
        if (customQuestions.isNotEmpty() && (Random.nextFloat() < 0.45f || difficultyLevel > 4)) {
            val custom = customQuestions.random()
            val options = listOf(custom.correctAnswer, custom.wrongOption1, custom.wrongOption2).shuffled()
            return MathChallenge(
                question = custom.questionText,
                correctAnswer = custom.correctAnswer,
                options = options,
                difficultyLevel = custom.difficulty
            )
        }

        // Procedural arithmetic generation
        val level = difficultyLevel.coerceIn(1, 5)
        return when (level) {
            1 -> generateSimpleAddition()
            2 -> if (Random.nextBoolean()) generateSimpleAddition() else generateSimpleSubtraction()
            3 -> if (Random.nextBoolean()) generateMediumAddition() else generateSimpleMultiplication()
            4 -> if (Random.nextBoolean()) generateMediumSubtraction() else generateSimpleMultiplication()
            else -> generateAdvancedMultiplicationOrMixed()
        }
    }

    private fun generateSimpleAddition(): MathChallenge {
        val a = Random.nextInt(3, 10)
        val b = Random.nextInt(2, 10)
        val answer = a + b
        val options = generateDistractors(answer)
        return MathChallenge(
            question = "$a + $b = ؟",
            correctAnswer = "$answer",
            options = options,
            difficultyLevel = 1
        )
    }

    private fun generateSimpleSubtraction(): MathChallenge {
        val b = Random.nextInt(2, 9)
        val answer = Random.nextInt(3, 10)
        val a = answer + b
        val options = generateDistractors(answer)
        return MathChallenge(
            question = "$a - $b = ؟",
            correctAnswer = "$answer",
            options = options,
            difficultyLevel = 2
        )
    }

    private fun generateMediumAddition(): MathChallenge {
        val a = Random.nextInt(12, 35)
        val b = Random.nextInt(7, 28)
        val answer = a + b
        val options = generateDistractors(answer)
        return MathChallenge(
            question = "$a + $b = ؟",
            correctAnswer = "$answer",
            options = options,
            difficultyLevel = 3
        )
    }

    private fun generateMediumSubtraction(): MathChallenge {
        val b = Random.nextInt(8, 25)
        val answer = Random.nextInt(10, 30)
        val a = answer + b
        val options = generateDistractors(answer)
        return MathChallenge(
            question = "$a - $b = ؟",
            correctAnswer = "$answer",
            options = options,
            difficultyLevel = 4
        )
    }

    private fun generateSimpleMultiplication(): MathChallenge {
        val a = Random.nextInt(2, 9)
        val b = Random.nextInt(2, 9)
        val answer = a * b
        val options = generateDistractors(answer)
        return MathChallenge(
            question = "$a × $b = ؟",
            correctAnswer = "$answer",
            options = options,
            difficultyLevel = 3
        )
    }

    private fun generateAdvancedMultiplicationOrMixed(): MathChallenge {
        val a = Random.nextInt(6, 12)
        val b = Random.nextInt(4, 9)
        val answer = a * b
        val options = generateDistractors(answer)
        return MathChallenge(
            question = "$a × $b = ؟",
            correctAnswer = "$answer",
            options = options,
            difficultyLevel = 5
        )
    }

    private fun generateDistractors(correctAnswer: Int): List<String> {
        val distractors = mutableSetOf<Int>()
        val offsets = listOf(-2, -1, 1, 2, 3, -3, 10, -10).shuffled()

        for (offset in offsets) {
            val candidate = correctAnswer + offset
            if (candidate != correctAnswer && candidate >= 0) {
                distractors.add(candidate)
            }
            if (distractors.size == 2) break
        }

        while (distractors.size < 2) {
            val rand = (correctAnswer + Random.nextInt(-4, 5)).coerceAtLeast(0)
            if (rand != correctAnswer) {
                distractors.add(rand)
            }
        }

        val allOptions = (distractors.toList() + correctAnswer).shuffled()
        return allOptions.map { it.toString() }
    }
}
